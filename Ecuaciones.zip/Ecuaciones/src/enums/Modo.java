package enums;

public enum Modo {
	Fraccion,
	fraccion,
	Decimal,
	decimal
}
