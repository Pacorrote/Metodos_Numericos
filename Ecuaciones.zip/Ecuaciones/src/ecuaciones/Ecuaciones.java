package ecuaciones;

import gui.InterfazPrin;

public class Ecuaciones {

	public static void main(String[] args) {
		new InterfazPrin();
	}

}
